import org.copperengine.core.Workflow;
import org.copperengine.core.Interrupt;
import org.copperengine.core.util.Backchannel;
import org.copperengine.core.AutoWire;

public class Workflow1 extends Workflow<String> {

    private static final long serialVersionUID = 1L;

    private Backchannel backChannel;

    @AutoWire
    public void setBackChannel(Backchannel backChannel) {
        this.backChannel= backChannel;
    }
		 

    @Override
    public void main() throws Interrupt {
		  java.lang.System.out.println("V2.0");
			backChannel.notify("correlationId", "V2.0");
    }

}
