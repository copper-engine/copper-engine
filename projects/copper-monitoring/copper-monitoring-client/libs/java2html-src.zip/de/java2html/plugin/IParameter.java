package de.java2html.plugin;

/**
 * @author Markus Gebhard
 */
public interface IParameter {
  public String getName();
}
