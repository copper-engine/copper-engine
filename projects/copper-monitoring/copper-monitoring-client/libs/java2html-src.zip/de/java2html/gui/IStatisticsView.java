package de.java2html.gui;

import de.java2html.javasource.JavaSourceStatistic;

public interface IStatisticsView {

  public void setStatistics(JavaSourceStatistic statistic);

}
