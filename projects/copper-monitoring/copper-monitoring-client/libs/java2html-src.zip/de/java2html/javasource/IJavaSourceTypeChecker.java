package de.java2html.javasource;


/**
 * @author Markus Gebhard
 */
public interface IJavaSourceTypeChecker {
  public boolean isValid(JavaSourceType type);
}
