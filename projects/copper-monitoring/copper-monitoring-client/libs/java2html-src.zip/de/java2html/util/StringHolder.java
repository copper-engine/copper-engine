package de.java2html.util;

/**
 * @author Markus Gebhard
 */
public class StringHolder {
  private String value;

  public void setValue(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}